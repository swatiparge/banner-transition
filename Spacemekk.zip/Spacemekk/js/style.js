
$('.custom1').owlCarousel({
    animateOut: 'fadeOut',
    animateIn: 'fadeOut',
    items:1,
    autoHeight:false,
    smartSpeed:250,
	autoplay:true
});

$('.plan1').owlCarousel({
    animateOut: 'fadeOut',
    animateIn: 'fadeOut',
    items:1,
    smartSpeed:250,
	autoplay:true
});